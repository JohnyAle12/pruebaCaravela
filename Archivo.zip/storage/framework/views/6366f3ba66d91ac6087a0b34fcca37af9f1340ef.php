<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Caravela</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarText">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#">Clientes</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Facturas</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Mis facturas</a>
      </li>
    </ul>
  </div>
</nav><?php /**PATH /Users/johnyalejandroprieto/Desktop/Cursos Software/PruebaCaravela/resources/views/layouts/nav.blade.php ENDPATH**/ ?>